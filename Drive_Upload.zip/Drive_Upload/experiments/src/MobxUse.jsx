import React from 'react'
import { observer } from 'mobx-react-lite'
import Button from 'react-bootstrap/Button';

const MobxUse = ({ store }) => {

  const changeName = () => {
    const username = prompt('Enter Your Name');
    store.updateUser(username);
  }

  const addSubject = () => {
    const sub = prompt('Enter Your Subject');
    store.addSubject(sub);
  }

  return (
    <center>
      <h1>MOBX</h1>
      <h1>{store.userInfo.name}-{store.userInfo.id}</h1>
      <Button variant="warning" onClick={changeName}>Update Name</Button>{' '}
      <Button variant="info" onClick={addSubject}>Add Subject</Button>{' '}
      
      <h1>Subject List ! </h1>
      <h2>{
        store.userInfo.subject.map((item, index) => <p key={index}>{item}</p>)
      }</h2>
    </center>
  )
}

export default observer(MobxUse)
