import React from 'react'
import Button from 'react-bootstrap/Button';
import { Link } from 'react-router-dom';
const AllRoute = () => {
    return (
        <div>
            <Link to='/stopwatch'>
            <Button variant="primary" className='btn-lg'>Stop Watch</Button>{' '}
            </Link>
            <Link to='/memo'>
            <Button variant="secondary" className='btn-lg'>UseMemo</Button>{' '}
            </Link>
            <Link to='/callback'>
            <Button variant="success" className='btn-lg'>UseCallback</Button>{' '}
            </Link>
            <Link to='/mobx'>
            <Button variant="warning" className='btn-lg'>MOBX</Button>{' '}
            </Link>
            <Link to='/recoil'>
            <Button variant="info" className='btn-lg'>RECOIL</Button>{' '}
            </Link>
            

        </div>
    )
}

export default AllRoute
