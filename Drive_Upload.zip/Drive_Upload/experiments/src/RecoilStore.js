import {atom,selector } from "recoil";

export const userState = atom({
    key:"userInfo",
    default:{
        userId: "CE025",
        name:"Dhiren"
    }
})

export const charCountState = selector({
    key:"charCountState",
    get:({get}) => {
        const text = get(userState);
        return text.name.length;
    }
})