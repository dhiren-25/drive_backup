import React,{useState,useEffect,USEm, useMemo} from "react";
import './App.css'
import Button from 'react-bootstrap/Button';
import { Link } from "react-router-dom";

const UseMemo = () => {
    const [number, setNumber] = useState(0);
    const [dark, setDark] = useState(false);
    const doubleNum = useMemo(() =>{
        return slowFun(number);
    },[number])

    const themeStyle = useMemo(()=>{
        return {
            backgroundColor: dark ? 'black' :'white',
            color: dark ? 'white' : 'black'
        }
    },[dark])

    useEffect(() =>{
        console.log('Theme Change ho gaya!')
    },[themeStyle])

   function slowFun(num){
    for(let i = 0 ; i <= 10000000000000 ; i++){
        return num * 2;
    }
   } 

  return (
    <div className="cont">
      <input type="number" value={number} onChange={e => setNumber(parseInt(e.target.value))}/>
      <Button className="btn" variant="success" onClick={()=> setDark(pDark => !pDark)}>Change Theme</Button>
      <div style={themeStyle}>{doubleNum}</div>

      <Link to='/'>
            <Button variant="info">Home</Button>{' '}
            </Link>
    </div>
  )
}

export default UseMemo
