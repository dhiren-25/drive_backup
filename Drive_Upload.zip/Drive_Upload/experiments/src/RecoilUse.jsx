import React from 'react'
import {  useRecoilState, useRecoilValue } from 'recoil'
import { userState,charCountState } from './RecoilStore'

const RecoilUse = () => {
    const [userData,setUserData] = useRecoilState(userState);
    const charCount = useRecoilValue(charCountState);

    const onNameChange  = (e)=>{
        setUserData({
            ...userData,
            name:e.target.value
        });
    }
  return (
    <div>
      <h1> USE OF Recoill</h1>
      <h2>User id : {userData.userId}</h2>
      <h2>{userData.name}</h2>
        <h2>count is : {charCount}</h2>
      <input type='text' value={userData.name} onChange={onNameChange}/>
    </div>
  )
}

export default RecoilUse
