import React, { useEffect, useState } from 'react';
import axios from 'axios';

const Try = () => {
  const [result, setResult] = useState(null);
  const [error, setError] = useState(null); // State for error handling

  const fetchData = async () => {
    try {
      const res = await axios.get('https://fakeapi.extendsclass.com/pokemons');
      setResult(res.data);
      console.log(res.data)
    } catch (error) {
      setError(error); // Store error for UI display
      console.error(error);
    }
  };

  useEffect(() => {
    fetchData();
  }, []); // Run fetchData only on component mount (optional: add dependencies for refetching)

  return (
    <div>
        <h1>P O K E M O N S</h1>
      {error ? (
        <p>Error fetching data: {error.message}</p>
      ) : result ? (

            <>

          <table class="table">
  <thead>
    
    <tr>
      <th scope="col">id</th>
      <th scope="col">Name</th>
      <th scope="col">Types</th>
      <th scope="col">Height</th>
    </tr>
  </thead>
  <tbody>
  {result.map((res) => (
    <tr> 
      <td>{res.id}</td>
      <td>{res.name}</td>
      <td>{res.types}</td>
      <td>{res.height}</td>
    </tr>
))}
  </tbody>

</table>
            </>
          
        
      ) : (
        <p>Loading...</p> // Display loading indicator while fetching
      )}
    </div>
  );
};

export default Try;
