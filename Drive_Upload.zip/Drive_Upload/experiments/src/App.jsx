import React from 'react'
import MapItem from './map.jsx'
import StopWatch from './StopWatch.jsx'
import CommentList from './CommentList.jsx'
import Try from './try.jsx'
import TodoListttt from './todoList.jsx'
import UseMemo from './UseMemo.jsx'
import UseCallback from './UseCallback.jsx'
import 'bootstrap/dist/css/bootstrap.min.css';
import { BrowserRouter, Router, Routes, Route } from 'react-router-dom'

import 'primeicons/primeicons.css';

import './App.css'
import AllRoute from './AllRoute.jsx'
import MobxUse from './MobxUse.jsx'
import UserStore from './UserStore'
import RecoilUse from './RecoilUse.jsx'
import { RecoilRoot } from 'recoil'
import Recoil2 from './Recoil2.jsx'
import ReduxUse from './ReduxUse.jsx'

const App = () => {
  const store = new  UserStore();

  return (
    <BrowserRouter>
    <Routes>
      <Route path='/' element={<AllRoute/>} />
      <Route path='/stopwatch' element={<StopWatch/>}/>
      <Route path='/memo' element={<UseMemo/>}/>
      <Route path='/callback' element={<UseCallback/>}/>
      <Route path='/redux' element={<ReduxUse/>}/>
      <Route path='/mobx' element={<MobxUse store = {store} />}/>


      <Route path='/recoil' element={
        <RecoilRoot>
        <RecoilUse  />
        <Recoil2/>
        </RecoilRoot>
        
        }/>
      

    </Routes>
      {/* <div className='cont'>
        <h2>Stop Watch</h2>
        <StopWatch />
      </div>

      <div className='cont'>
        <h2>USE MEMO</h2>
        <UseMemo />
      </div>
      <div className='cont'>
        <h2>USE CallBack</h2>
        <UseCallback />
      </div> */}
    </BrowserRouter>
  )
}

export default App

