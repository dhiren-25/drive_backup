import React, { useRef, useState } from 'react'
import './App.css'
import Button from 'react-bootstrap/Button';
import { Link } from 'react-router-dom';
        

const StopWatch = () => {

  const [startTime, SetStartTime] = useState(null);
  const [now, setNow] = useState(null);
  const intervalRef = useRef(null);

  const handleStart = () => {
    SetStartTime(Date.now());

    setNow(Date.now());
    clearInterval(intervalRef.current);

    intervalRef.current = setInterval(() => {
      setNow(Date.now);
    }, 10);
  }

  const handleStop = () => {
    clearInterval(intervalRef.current);
    const timee = Date();
    const timein_minsec = timee.getMinutes() + ":" + timee.getSeconds();
    console.log(timein_minsec)
  }



  let secondpass = 0;

  if (startTime != null && now != null) {
    secondpass = (now - startTime) / 1000;
  }

  return (
    <div className='cont'>
      
      <h1>Time Passed: {secondpass.toFixed(3)}</h1>
      <Button className='btn' variant="success" onClick={handleStart}>Start</Button>
      &nbsp;
      <Button className='btn'  variant="danger" onClick={handleStop}>Stop</Button>
     
      
      <Link to='/'>
            <Button variant="info">Home</Button>{' '}
            </Link>
    </div>
  )
}

export default StopWatch
