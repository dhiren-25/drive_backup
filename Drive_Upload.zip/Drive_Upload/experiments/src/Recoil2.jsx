import React from 'react'
import {  useRecoilState, useRecoilValue } from 'recoil'
import { userState,charCountState } from './RecoilStore'

const Recoil2 = () => {

    const [userData,setUserData] = useRecoilState(userState);

  return (
    <div>
        <h1>Recoil USe 2</h1>
       <h2>{userData.name}</h2>
    </div>
  )
}

export default Recoil2
