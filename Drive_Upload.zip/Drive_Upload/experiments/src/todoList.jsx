import React from 'react';
import { createContext,useContext } from 'react';

const ThemeContext = createContext(null);

export default function MyApp () {

  return (
    <ThemeContext.Provider value="dark">
     <Form/>
    </ThemeContext.Provider>
  )
}

function Form(){
  return(
    <Panel title="WelCome">
      
      <Button>Sign Up</Button>
      <Button>Sign In</Button>
    </Panel>
  )
}

function Panel({title,children}){
  const theme = useContext(ThemeContext);
  const className = 'Panel-' + theme;

  return(
    <section className={className}>
      <h1>{title}</h1>
      {children}
    </section>
  )
}


function Button({children}){
  const theme = useContext(ThemeContext);
  const className = 'button-' + theme;

  return(
    <button className={className}>
      {children}
    </button>
  )
}

