import { action,computed,makeObservable,observable,autorun,runInAction } from "mobx";

class UserStore{
    userInfo= {
        id: 'CE006',
        name:'Dhiren',
        subject:['Math','English','Hindi']
    }

    constructor(){
        makeObservable(this,{
            userInfo:observable,
            totalSubject : computed,
            updateUser: action,
            addSubject:action
        });
        autorun(this.logUserDetails);
        runInAction(this.prefetchData);
    }

    get totalSubject(){
        console.log("getter");
        return this.userInfo.subject.length;
    }
    logUserDetails = ()=>{
        console.log("Subject Length is "+ this.totalSubject + ' Name:- ' + this.userInfo.name);
    }


    prefetchData  = () =>{
        console.log("Run IN Action");
    }

   
    updateUser(name ){
        return this.userInfo.name = name ;
    }

    addSubject(data){
        return this.userInfo.subject = [...this.userInfo.subject,data];
    }
}


export default UserStore;