import { configureStore } from "@reduxjs/toolkit";


const reducerFn = (state = {counter : 0 },action ) =>{
    return state;
}

const reduxStore = configureStore(reducerFn);

export default reduxStore;