import React from 'react'

const Header = () => {
  return (
    <h1 className="display-5 fw-bold text-body-emphasis">Counter With Redux</h1>
  )
}

export default Header
