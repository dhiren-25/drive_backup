import React from 'react'

const Main = () => {
  return (
    <div>
        
       <div className="main">
        <h2 className="main-header">React Crud Operations</h2>
        </div>
    </div>
  )
}

export default Main
