import React from 'react';
import { Card } from 'primereact/card';
import { Skeleton } from 'primereact/skeleton';

const data = [
  {
    src: 'https://i.ytimg.com/vi/pLqipJNItIo/hqdefault.jpg?sqp=-oaymwEYCNIBEHZIVfKriqkDCwgBFQAAiEIYAXAB&rs=AOn4CLBkklsyaw9FxDmMKapyBYCn9tbPNQ',
    title: 'Don Diablo @ Tomorrowland Main Stage 2019 | Official…',
    channel: 'Don Diablo',
    views: '396k views',
    createdAt: 'a week ago',
  },
  {
    src: 'https://i.ytimg.com/vi/_Uu12zY01ts/hqdefault.jpg?sqp=-oaymwEZCPYBEIoBSFXyq4qpAwsIARUAAIhCGAFwAQ==&rs=AOn4CLCpX6Jan2rxrCAZxJYDXppTP4MoQA',
    title: 'Queen - Greatest Hits',
    channel: 'Queen Official',
    views: '40M views',
    createdAt: '3 years ago',
  },
  {
    src: 'https://i.ytimg.com/vi/kkLk2XWMBf8/hqdefault.jpg?sqp=-oaymwEYCNIBEHZIVfKriqkDCwgBFQAAiEIYAXAB&rs=AOn4CLB4GZTFu1Ju2EPPPXnhMZtFVvYBaw',
    title: 'Calvin Harris, Sam Smith - Promises (Official Video)',
    channel: 'Calvin Harris',
    views: '130M views',
    createdAt: '10 months ago',
  },
];

const Media = ({ loading = false }) => {
  return (
    <div className="p-d-flex p-flex-row">
      {(loading ? Array.from(new Array(3)) : data).map((item, index) => (
        <Card key={index} style={{ width: '210px', marginRight: '0.5rem', marginBottom: '1rem' }}>
          {item ? (
            <img
              style={{ width: '100%', height: '118px' }}
              alt={item.title}
              src={item.src}
            />
          ) : (
            <Skeleton shape="rectangular" style={{ width: '210px', height: '118px' }} />
          )}
          <div style={{ padding: '0.5rem' }}>
            {item ? (
              <>
                <h5 style={{ marginBottom: '0.5rem' }}>{item.title}</h5>
                <span style={{ marginBottom: '0.25rem' }}>{item.channel}</span>
                <br />
                <span>{`${item.views} • ${item.createdAt}`}</span>
              </>
            ) : (
              <>
                <Skeleton style={{ marginBottom: '0.25rem' }} />
                <Skeleton width="60%" />
              </>
            )}
          </div>
        </Card>
      ))}
    </div>
  );
};

const YouTube = () => {
  return (
    <div style={{ overflow: 'auto' }}>
      <Media loading />
      <Media />
    </div>
  );
};

export default YouTube;
