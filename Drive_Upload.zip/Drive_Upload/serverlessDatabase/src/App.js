import './App.css';
import Create from './components/Create';
import Main from './components/Main';
import BasicDemo from './components/Prime';
import Read from './components/Read';
import Update from './components/Update';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import 'primereact/resources/themes/saga-blue/theme.css';
import 'primereact/resources/primereact.min.css';
import 'primeicons/primeicons.css';

import YouTube from './components/Prime';
import TemplateDemo from './components/Prime';

function App() {
  return (
    <Router>
      <div className="main">
        <h2 className="main-header">React Crud Operations</h2>
        
        <Routes>

          <Route path="/" element={<Main />} />
          <Route path="/create" element={<Create />} />
          <Route path="/read" element={<Read />} />
          <Route path="/update" element={<Update />} />
          <Route path="/prime" element={<TemplateDemo />} />
        </Routes>
      </div>
    </Router>
  );
}

export default App;
