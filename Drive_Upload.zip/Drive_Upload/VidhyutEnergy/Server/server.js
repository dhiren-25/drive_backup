// server.js
const express = require('express');
const bodyParser = require('body-parser');
const nodemailer = require('nodemailer');

const app = express();
const PORT = process.env.PORT || 5000;

// Middleware
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

// API endpoint for handling form submissions
app.post('/api/contact', async (req, res) => {
  try {
    const { fullname, email, phone, subject, message } = req.body;

    // Create a nodemailer transporter
    const transporter = nodemailer.createTransport({
      service: 'Gmail',
      auth: {
        user: 'paxtonop2525@gmail.com', // Enter your email here
        pass: 'pax#@777'   // Enter your email password here
      }
    });

    // Email message options
    const mailOptions = {
      from: 'your-email@gmail.com',
      to: 'paxtonop2525@gmail.com', // Enter recipient email here
      subject: subject,
      text: `Name: ${fullname}\nEmail: ${email}\nPhone: ${phone}\n\nMessage: ${message}`
    };

    // Send email
    await transporter.sendMail(mailOptions);

    res.status(200).json({ message: 'Message sent successfully' });
  } catch (error) {
    console.error('Error sending email:', error);
    res.status(500).json({ error: 'Failed to send message' });
  }
});

// Start the server
app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});
