import React from 'react'
import './style.scss'
const PageNotFound = () => {
  return (
    <div>
      
    </div>
  )
}

export default PageNotFound
