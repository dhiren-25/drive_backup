import React from 'react'
import './style.scss'
const Explore = () => {
  return (
    <div>
    
    </div>
  )
}

export default Explore
