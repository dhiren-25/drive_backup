import React from 'react'
import './style.scss'
const SearchResult = () => {
  return (
    <div>
      Searchhh
    </div>
  )
}

export default SearchResult
