import React from 'react'
import './style.scss'
const Details = () => {
  return (
    <div>
      
    </div>
  )
}

export default Details
