import React, { useState, useEffect } from 'react';
import { Tree } from 'primereact/tree';
import { Accordion, AccordionTab } from 'primereact/accordion';

export default function BasicDemo() {
    const [nodes, setNodes] = useState([]);
    const [expandedKeys, setExpandedKeys] = useState([]);

    const data = [
        {
            key: '0',
            label: 'Documents',
            data: 'Documents Folder',
            para: 'Value to describe the component can either be provided with aria-labelledby or aria-label props. The root list element has a tree role whereas each list item has a treeitem role along with aria-label, aria-selected and aria-expanded attributes. In checkbox selection, aria-checked is used instead of aria-selected. The container element o',
            icon: 'pi pi-fw pi-inbox',
            children: [
                {
                    key: '0-0',
                    label: 'Work',
                    data: 'Work Folder',
                    icon: 'pi pi-fw pi-cog',
                    children: [
                        { key: '0-0-0', label: 'Expenses.doc', icon: 'pi pi-fw pi-file', data: 'Expenses Document' },
                        { key: '0-0-1', label: 'Resume.doc', icon: 'pi pi-fw pi-file', data: 'Resume Document' }
                    ]
                },
                {
                    key: '0-1',
                    label: 'Home',
                    data: 'Home Folder',
                    icon: 'pi pi-fw pi-home',
                    children: [{ key: '0-1-0', label: 'Invoices.txt', icon: 'pi pi-fw pi-file', data: 'Invoices for this month' }]
                }
            ]
        },
        {
            key: '1',
            label: 'Events',
            data: 'Events Folder',
            para: 'Value to describe the component can either be provided with aria-labelledby or aria-label props. The root list element has a tree role whereas each list item has a treeitem role along with aria-label, aria-selected and aria-expanded attributes. In checkbox selection, aria-checked is used instead of aria-selected. The container element o',
            icon: 'pi pi-fw pi-calendar',
            children: [
                {
                    key: '1-0',
                    label: 'Meeting',
                    data: 'Meeting Folder',
                    icon: 'pi pi-fw pi-users',
                    children: [{
                        key: '1-1',
                        label: 'Product Launch',
                        data: 'Product Launch Folder',
                        icon: 'pi pi-fw pi-rocket',
                        children: []
                    }]
                },
                {
                    key: '1-2',
                    label: 'Report Review',
                    data: 'Report Review Folder',
                    icon: 'pi pi-fw pi-file-o',
                    children: []
                }
            ]
        },
        {
            key: '2',
            label: 'Movies',
            data: 'Movies Folder',
            para: 'Value to describe the component can either be provided with aria-labelledby or aria-label props. The root list element has a tree role whereas each list item has a treeitem role along with aria-label, aria-selected and aria-expanded attributes. In checkbox selection, aria-checked is used instead of aria-selected. The container element o',
            icon: 'pi pi-fw pi-video',
            children: [
                {
                    key: '2-0',
                    label: 'Al Pacino',
                    data: 'Al Pacino Folder',
                    icon: 'pi pi-fw pi-star',
                    children: [
                        { key: '2-0-0', label: 'Scarface', icon: 'pi pi-fw pi-film', data: 'Scarface Movie' },
                        { key: '2-0-1', label: 'Serpico', icon: 'pi pi-fw pi-film', data: 'Serpico Movie' }
                    ]
                },
                {
                    key: '2-1',
                    label: 'Robert De Niro',
                    data: 'Robert De Niro Folder',
                    icon: 'pi pi-fw pi-star',
                    children: [
                        { key: '2-1-0', label: 'Goodfellas', icon: 'pi pi-fw pi-film', data: 'Goodfellas Movie' },
                        { key: '2-1-1', label: 'Untouchables', icon: 'pi pi-fw pi-film', data: 'Untouchables Movie' }
                    ]
                }
            ]
        }
    ];

    useEffect(() => {
        setNodes(data);
    }, []);

    const AccExpan = (index) => {
        console.log('Clicked AccordionTab index:', index);
        const expandedKeysCopy = [...expandedKeys];
        expandedKeysCopy[index] = !expandedKeys[index]; // Toggle the state of the expanded key
        setExpandedKeys(expandedKeysCopy);
    };

    return (
        <div className="flex">
            <div className="card flex justify-content-center w-1/2">
                <Tree
                    value={nodes}
                    className="w-full"
                    selectionMode="single"
                    expandedKeys={expandedKeys}
                    onToggle={(e) => setExpandedKeys(e.value)}
                />
            </div>
            <div className="card w-1/2">
                <Accordion
                    multiple
                    activeIndex={expandedKeys.map((val, index) => val ? index : null)}
                    onTabChange={(e) => setExpandedKeys(e.index)}
                >
                    {data.map((node, index) => (
                        <AccordionTab key={node.key} header={node.label} onClick={() => AccExpan(index)}>
                            <p>{node.para}</p>
                        </AccordionTab>
                    ))}
                </Accordion>
            </div>
        </div>
    );
}
