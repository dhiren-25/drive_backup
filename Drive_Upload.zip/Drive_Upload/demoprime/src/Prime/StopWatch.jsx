import React, { useState } from 'react'

const StopWatch = () => {

    const[startTime,SetStartTime] = useState(null);
    const [now, setNow] = useState(null);

    const handleStart = () =>{
        SetStartTime(Date.now());

        setNow(Date.now());

        setInterval(() => {
            setNow(Date.now);
        },10);
    }

    let secondpass = 0;

    if(startTime != null && now != null){
        secondpass = (now-startTime) / 1000;
    }

  return (
    <div>
        <h1>Time Passed : {secondpass.toFixed(3)}</h1>
      <button onClick={handleStart}>Start</button>
    </div>
  )
}

export default StopWatch
