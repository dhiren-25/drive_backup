import React, { useState } from "react";
import { Button } from "primereact/button";

export default function IconDemo() {
    const [date, setDate] = useState(null);

    return (
        <div>
            <div className="p-2 border-round-xl" style={{ background: 'var(--style-cards-fancy-bg)', border: '1px solid rgba(255, 255, 255, 0.1)', width: '300px' }}>
                <div className="content border-round-sm">
                    <div className="content-image bg-cover bg-no-repeat bg-center relative" style={{ height: '244px', backgroundImage: 'url("https://www.primefaces.org/cdn/primeflex/images/landing/style-cards/fancy.jpg")' }}>
                        <div className="rating mt-2 border-round-sm absolute ml-2 p-2 flex align-items-center gap-2 bg-black-alpha-20 w-8rem border-1" style={{ backdropFilter: 'blur(27px)' }}>
                            <i className="pi pi-star-fill text-white"></i>
                            <i className="pi pi-star-fill text-white"></i>
                            <i className="pi pi-star-fill text-white"></i>
                            <i className="pi pi-star-fill text-gray-600"></i>
                            <i className="pi pi-star-fill text-gray-600"></i>
                        </div>
                    </div>
                    <div className="content-info mt-2 border-round-sm bg-white-alpha-10 shadow-1 py-1" style={{ backdropFilter: 'blur(27px)' }}>
                        <div className="flex align-items-center justify-content-between py-2 px-3">
                            <span className="font-medium text-white">Prime Coffee Shop</span>
                            <i className="pi pi-verified text-white"></i>
                        </div>
                        <div className="flex align-items-center justify-content-between py-2 px-3 gap-2">
                            <div className="flex align-items-center gap-2">
                                <i className="pi pi-star-fill text-white"></i>
                                <span className="font-small text-white white-space-nowrap">Cold Brew</span>
                            </div>
                            <div className="flex align-items-center gap-2">
                                <i className="pi pi-star-fill text-white"></i>
                                <span className="font-small text-white white-space-nowrap">10:00 - 17:00</span>
                            </div>
                        </div>
                        <div className="flex align-items-center justify-content-between py-2 px-3 gap-2">
                            <div className="flex align-items-center justify-content-center gap-1 border-right-1 surface-border pr-2">
                                <i className="pi pi-bolt text-white"></i>
                                <span className="font-small text-white white-space-nowrap">Charge</span>
                            </div>
                            <div className="flex align-items-center gap-1 justify-content-center gap-1 border-right-1 surface-border px-2">
                                <i className="pi pi-wifi text-white"></i>
                                <span className="font-small text-white white-space-nowrap">Wifi</span>
                            </div>
                            <div className="flex align-items-center gap-1 justify-content-center gap-1 pl-2">
                                <i className="pi pi-book text-white"></i>
                                <span className="font-small text-white white-space-nowrap">Library</span>
                            </div>
                        </div>
                    </div>
                    <div className="flex align-items-center justify-content-center pt-2 gap-2">
                        <button className="p-3 flex align-items-center justify-content-center w-7 gap-2 border-round-sm bg-white-alpha-10 shadow-1 border-none cursor-pointer hover:bg-white-alpha-20 transition-duration-200" style={{ backdropFilter: 'blur(27px)' }}>
                            <span className="font-medium text-white white-space-nowrap">Contact</span>
                            <i className="pi pi-send text-white"></i>
                        </button>
                        <button className="p-3 flex align-items-center justify-content-center w-5 gap-2 bg-blue-500 shadow-1 border-round-sm border-none cursor-pointer hover:bg-blue-600 transition-duration-200">
                            <span className="font-medium text-white white-space-nowrap">Rate</span>
                            <i className="pi pi-thumbs-up-fill text-white"></i>
                        </button>
                    </div>
                </div>
            </div>
        </div>
    );
}
