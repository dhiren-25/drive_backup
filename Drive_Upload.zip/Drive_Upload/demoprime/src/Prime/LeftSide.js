import React, { useState, useEffect, useRef } from 'react';
import { Tree } from 'primereact/tree';
import { Accordion, AccordionTab } from 'primereact/accordion';
import { Toast } from 'primereact/toast';
import './Style.css';

export default function LeftSide() {
    const [nodes, setNodes] = useState([]);
    const [activeIndex, setActiveIndex] = useState(null);
    const toast = useRef(null);
    // const[selectedNode,setSelectedNode] = useState(0);
    // const [open, setOpen] = useState(false);
    const data = [
        {
            key: '0',
            label: 'Documents',
            data: 'Documents Folder',
            icon: 'pi pi-fw pi-inbox',
            children: [
                {
                    key: '0-0',
                    label: 'Work',
                    data: 'Work Folder',
                    icon: 'pi pi-fw pi-cog',
                    children: [
                        { key: '0-0-0', label: 'Expenses.doc', icon: 'pi pi-fw pi-file', data: 'Expenses Document' },
                        { key: '0-0-1', label: 'Resume.doc', icon: 'pi pi-fw pi-file', data: 'Resume Document' }
                    ]
                },
                {
                    key: '0-1',
                    label: 'Home',
                    data: 'Home Folder',
                    icon: 'pi pi-fw pi-home',
                    children: [{ key: '0-1-0', label: 'Invoices.txt', icon: 'pi pi-fw pi-file', data: 'Invoices for this month' }]
                }
            ]
        },
        {
            key: '1',
            label: 'Events',
            data: 'Events Folder',
            icon: 'pi pi-fw pi-calendar',
            children: [
                {
                    key: '1-0',
                    label: 'Meeting',
                    data: 'Meeting Folder',
                    icon: 'pi pi-fw pi-users',
                    children: [{
                        key: '1-1',
                        label: 'Product Launch',
                        data: 'Product Launch Folder',
                        icon: 'pi pi-fw pi-rocket',
                        children: []
                    }]
                },

                {
                    key: '1-2',
                    label: 'Report Review',
                    data: 'Report Review Folder',
                    icon: 'pi pi-fw pi-file-o',
                    children: []
                }
            ]
        },
        {
            key: '2',
            label: 'Movies',
            data: 'Movies Folder',
            icon: 'pi pi-fw pi-video',
            children: [
                {
                    key: '2-0',
                    label: 'Al Pacino',
                    data: 'Al Pacino Folder',
                    icon: 'pi pi-fw pi-star',
                    children: [
                        { key: '2-0-0', label: 'Scarface', icon: 'pi pi-fw pi-film', data: 'Scarface Movie' },
                        { key: '2-0-1', label: 'Serpico', icon: 'pi pi-fw pi-film', data: 'Serpico Movie' }
                    ]
                },
                {
                    key: '2-1',
                    label: 'Robert De Niro',
                    data: 'Robert De Niro Folder',
                    icon: 'pi pi-fw pi-star',
                    children: [
                        { key: '2-1-0', label: 'Goodfellas', icon: 'pi pi-fw pi-film', data: 'Goodfellas Movie' },
                        { key: '2-1-1', label: 'Untouchables', icon: 'pi pi-fw pi-film', data: 'Untouchables Movie' }
                    ]
                }
            ]
        }
    ];

    useEffect(() => {
        console.log("Active Index:", activeIndex);
    }, [activeIndex])

    // const onTreeSelect = (e) => {
    //     console.log("event.node",parseInt(e.node.key));
    //     let nodeKey = e.node.key;
    //     setActiveIndex(parseInt(nodeKey)); 

    // };

    const onTreeSelect = (e) => {
        // console.log({e});
        const nodeKey = e.node.key;
        const indexes = nodeKey.split('-').map(index => parseInt(index));
        console.log("Selected Node Indexes:", indexes);
        // setSelectedNode(indexes);

        const fullHierarchyIndexes = [];
        let currentIndexes = [];
        indexes.forEach(index => {
            currentIndexes.push(index);
            fullHierarchyIndexes.push([...currentIndexes]);
        });

        console.log("Full Hierarchy Indexes:", fullHierarchyIndexes);
        

        setActiveIndex(indexes);
        let str;

        if (indexes == 0) {
            str = "First";
        } else if (indexes == 1) {
            str = "Second";
        } else if (indexes == 2) {
            str = "Third";
        }

        toast.current.show({ severity: 'success', summary: `${str} Accordion Khul GAYA !`, detail: e.node.label });


    };


    // const onSelect = (event) => {
    //     toast.current.show({ severity: 'info', summary: 'Node Selected', detail: event.node.label });
    //     // onUnselect(event);
    // };

    const onUnselect = (event) => {
        console.log('"Unselected"')
        toast.current.show({ severity: 'warn', summary: 'Node Unselected', detail: event.node.label });
    };

    useEffect(() => {
        setNodes(data);

    }, []);



    const onTreeUnselect = () => {
        setActiveIndex(null);
        // setSelectedNode(null);
        console.log({ activeIndex });
    };

    // const accordionClick = (index) =>{
    //     setActiveIndex(index);
    //     console.log({activeIndex});
    // }
    return (
        <>
        <br/>
            <Toast ref={toast} />
            <div className="container">
                <div className="card tree-container">
                    <Tree
                        value={nodes}
                        className="w-full"
                        selectionMode="single"
                        onExpand={onTreeSelect}
                        // onSelect={onTreeSelect}
                        onUnselect={onUnselect}
                        // onSelectionChange={onTreeUnselect}
                        onCollapse={onTreeUnselect}
                    />
                </div>
                <div className="card accordion-container">
                    <Accordion multiple activeIndex={activeIndex} onTabChange={(e) => setActiveIndex(e.index)} >
                        <AccordionTab header="Header I">

                            <Accordion activeIndex={activeIndex} onTabChange={(e) => setActiveIndex(e.index)} >
                                <AccordionTab header="Sub Header I">
                                    <p className="m-0">
                                        Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
                                        Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea
                                        commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.
                                        Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
                                    </p>
                                </AccordionTab>
                            </Accordion>

                            <Accordion activeIndex={activeIndex} onTabChange={(e) => setActiveIndex(e.index)}>
                                <AccordionTab header="Sub Header II">
                                    <p className="m-0">
                                        Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
                                        Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea
                                        commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.
                                        Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
                                    </p>
                                </AccordionTab>
                            </Accordion>



                        </AccordionTab>
                        <AccordionTab header="Header II">
                            <Accordion activeIndex={activeIndex} onTabChange={(e) => setActiveIndex(e.index)}>
                                <AccordionTab header="Sub Header I">
                                    <p className="m-0">
                                        Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
                                        Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea
                                        commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.
                                        Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
                                    </p>
                                </AccordionTab>
                            </Accordion>

                            <Accordion activeIndex={activeIndex} onTabChange={(e) => setActiveIndex(e.index)}>
                                <AccordionTab header="Sub Header II">
                                    <p className="m-0">
                                        Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
                                        Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea
                                        commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.
                                        Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
                                    </p>
                                </AccordionTab>
                            </Accordion>

                        </AccordionTab>
                        <AccordionTab header="Header III">
                            <Accordion activeIndex={activeIndex} onTabChange={(e) => setActiveIndex(e.index)}>
                                <AccordionTab header="Sub Header I">
                                    <p className="m-0">
                                        Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
                                        Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea
                                        commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.
                                        Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
                                    </p>
                                </AccordionTab>
                            </Accordion>

                            <Accordion activeIndex={activeIndex} onTabChange={(e) => setActiveIndex(e.index)}>
                                <AccordionTab header="Sub Header II">
                                    <p className="m-0">
                                        Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
                                        Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea
                                        commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.
                                        Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
                                    </p>
                                </AccordionTab>
                            </Accordion>

                        </AccordionTab>
                    </Accordion>

                </div>
            </div>
        </>
    );
}
