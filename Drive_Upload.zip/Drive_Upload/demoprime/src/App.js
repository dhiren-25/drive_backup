import './App.css';


import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import 'primereact/resources/themes/saga-blue/theme.css';
import 'primereact/resources/primereact.min.css';
import 'primeicons/primeicons.css';

// import BasicDemo1 from './Prime/AutoComplete';
import BasicDemo from './Prime/AutoComplete';
import IconDemo from './Prime/Calender';
import TemplateDemo from './Prime/Button';
import GroupDemo from './Prime/FloatLabel';
import Reverse from './Prime/reverse';
import Reverse2 from './Prime/reverse2';
import LeftSide from './Prime/LeftSide';


function App() {
  return (
    <Router>
      
      
        
        <Routes>
          <Route path="/" element={<BasicDemo/>} />
          <Route path="/" element={<TemplateDemo />} />
          <Route path="/basic" element={<Reverse />} />
          <Route path="/basic2" element={<Reverse2 />} />
          <Route path="/left" element={<LeftSide />} />
          <Route path="/calender" element={<IconDemo />} />
        
        </Routes>
      
    </Router>
  );
}

export default App;
