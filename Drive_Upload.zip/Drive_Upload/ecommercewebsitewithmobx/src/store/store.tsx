import { makeAutoObservable } from "mobx";
import { createContext, useContext } from "react";
import axios, { AxiosResponse } from "axios";

// Step 1: Define interfaces
interface Post {
  userId: number;
  id: number;
  title: string;
  body: string;
}

interface PostStoreInterface {
  posts: Post[];
  loading: boolean;
  fetchPosts: () => Promise<void>;
}

// Step 2: Create a context
const PostStoreContext = createContext<PostStoreInterface | null>(null);

class PostStore implements PostStoreInterface {
  posts: Post[] = [];
  loading = false;

  constructor() {
    makeAutoObservable(this);
  }

  async fetchPosts() {
    this.loading = true;
    try {
      const response: AxiosResponse<Post[]> = await axios.get("https://jsonplaceholder.typicode.com/posts");
      this.posts = response.data;
    } catch (error) {
      console.error("Error fetching posts:", error);
    } finally {
      this.loading = false;
    }
  }
}

// Step 3: Instantiate the store
const postStore = new PostStore();

// Step 4: Provide the store
export const PostStoreProvider: React.FC = ({ children }) => {
  return (
    <PostStoreContext.Provider value={postStore}>
      {children}
    </PostStoreContext.Provider>
  );
};

// Step 5: Consume the store
export const usePostStore = (): PostStoreInterface => {
  const store = useContext(PostStoreContext);
  if (!store) {
    throw new Error("usePostStore must be used within a PostStoreProvider");
  }
  return store;
};
