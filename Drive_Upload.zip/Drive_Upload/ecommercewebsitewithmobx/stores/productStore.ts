import axios from "axios";
import { action, computed, makeAutoObservable, makeObservable, observable } from "mobx";
import { IRootStore } from "./RootStore";

export interface Rating{
    rate:number;
    count:number;
}

export interface IProducts{
    id:number;
    title:string;
    price:number;
    description:string;
    category:string;
    image:string;
    rating:Rating;
}

export class ProductStore{
    products: IProducts[] = [];
    rootStore: IRootStore;

    constructor(rootStore: IRootStore){
        makeAutoObservable(this,{
            products:observable,
            fetchProducts : action,
            getProducts: computed,
        });
        this.rootStore = rootStore;
    }

    async fetchProducts(){
        const prRes = await axios.get("https://fakestoreapi.com/products");
        this.products = prRes?.data ?? [];
    }

    get getProducts(){
        return this.products;
    }
}